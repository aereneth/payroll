<?php
	include('conn.php');
	$id=$_GET['id'];
	$query="DELETE FROM account WHERE id=$id";
	$result=mysql_query($query);
	header("location: employee.php");
?>